#Greet the User and Explain the Game
print("---------------------------------")
print("Welcome to the Prince's Quest")
print("---------------------------------")
print("")


#Introduce the User's Role
print("You are trying to save the princess from the tower!")
print("But first, you must find the magic key.") 
print("")

#Set the Scene
print("You are Passing Through a Village and Encounter Many People. You Can Speak To:")
print("A. The Witch, who Can See into the Future")
print("B. The Blacksmith, who Created and Hid the Key")
print("C. The Local Townsmen, who Know the History of the Village")
answer = input("Which Option Would You Like to Choose? (Type A, B, or C): ")
print("")

#Speaking With the Witch
if answer == "A":
  print("You Decide to Speak with the Witch.")
  print("She Tells You it is Guarded by Adeline, the Great Fairy")
  print("You Choose to Go Towards:")
  print("A. The Forest")
  print("B. The Ocean")
  print("C. Further into the Town")
  print("D. The Mountain")
  answer = input("Where Would You Like to Go? (Type A, B, C or D): ")
  print("")
  if answer == "A":
    print("Congratulations! After Looking Through the Forest, You Met with the Fairy and Found the Key to the Tower! You Saved the Princess!")
  if answer == "B":
    print("You Lost Your Way and Were Unsuccessful.")
  if answer == "C":
    print("You Lost Your Way and Were Unsuccessful.")
  if answer == "D":
    print("You Lost Your Way and Were Unsuccessful")
    print("")

#Speaking With the Blacksmith
elif answer == "B":
  print("You Decide to Speak with the Blacksmith.")
  print("He Wants to Makes Sure You Are Qualified.")
  print("Before He Can Help You, You Must Answer This Question.")
  print("What Year Was the King's Castle Built?")
  answer = input("Type Your Answer:")
  print("")
  if answer == "1467":
    print("Congratulations! You Found the Key and Saved the Princess! ")
  if answer != "1467":
    print("The Blacksmith Does Not Deem You Qualified. You Were Unsuccessful.")

#Speaking With the Townsmen
elif answer == "C":
  print("You Decide to Speak with the Townsmen.")
  print("They Tell You About the History of the Village")
  print("To Get Directions to the Tower, You Must Answer This Question")
  print("What Month Did the Princess Get Taken to the Tower?")
  answer = input("Type Your Answer:")
  print("")
  if answer == "August":
    print("Congratulations! You Found the Key and Saved the Princess!")
  if answer!= "August":
    print("The Townsmen Are Upset That You Have Not Been Paying Attention and They Decide Not to Help You Any Further")

